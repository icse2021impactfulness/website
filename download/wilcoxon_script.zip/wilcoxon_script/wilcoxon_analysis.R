

#!/usr/bin/env Rscript

# Title     : Evaluate the metrics through the Wilcoxon Test
# Objective : Evaluate if there is a difference between impactful and unimpactful revisions

#' Wilcoxon Test
#'
#' @param input_data the input dataframe with metrics
#' @param metric the desired metric's name
wilcoxon_test <- function(input_data, metric, output_data) {
  
  # Set the impactiful and uninpactiful dists
  degraded_dist <- input_data[input_data$prediction == "True",][[metric]]
  clean_dist <- input_data[input_data$prediction == "False",][[metric]]
  
  # Compute the Wilcoxon Tests
  test <- wilcox.test(degraded_dist, clean_dist)
  test_greater <- wilcox.test(degraded_dist, clean_dist, alternative = "greater")
  test_less <- wilcox.test(degraded_dist, clean_dist, alternative = "less")
  
  # Get p-value of the two sided test
  pvalue <- test$p.value
  
  cliff_delta <- effsize::cliff.delta(degraded_dist, clean_dist)
  estimate <- cliff_delta$estimate
  magnitude <- cliff_delta$magnitude
    
  # Output data
  metric_data <- data.frame(metric = metric, pvalue = pvalue, bonferroni = 0, cliff = estimate, cliff_ctg = magnitude)
  return(metric_data)
  
}

# Set path of data
setwd("")

options(scipen=999)


# Projects and metrics set
projects <- c(
              "couchbase-java-client", "spymemcached", "couchbase-jvm-core", "eclipse.platform.ui", "egit", "jgit", "org.eclipse.linuxtools", 
              "all")

metrics <- c("inline_comments_num", "words_inline_comments_num", "percentage_words_in_inline_comments", "general_comments_num", "words_general_comments_num", 
             "percentage_words_in_general_comments", "discussion_length", "change_num", "recent_change_num", "dir_change_num", "review_num", "merged_ratio", 
             "recent_merged_ratio", "dir_merged_ratio", "lines_added_num", "lines_deleted_num", "churm_num", "file_added_num", "file_deleted_num", 
             "changed_file_num", "directory_num", "modify_entropy", "language_num", "file_type_num", "segs_added_num", "segs_deleted_num", "segs_updated_num", 
             "msg_length", "social_degree", "social_closeness", "social_betweenness", 
             "social_eigenvector", "social_clustering", "social_k_coreness", "number_of_file_developers", "number_of_file_modifications")


input_types <- c(
				         "impactful_coarse_grained_smells-",
                 "impactful_fine_grained_smells-"
                 )
				 
for (input_type in input_types){
	for (project in projects) {
	  
	  # Create the output dataframe
	  output_data <- data.frame(metric = character(), pvalue = double(), bonferroni = double(), cliff = double(), cliff_ctg = character())
	  
	  path <- paste0(input_type, project)

	  # Load the current set of metrics
	  current_metrics <- read.csv(paste0(path, ".csv"))
	  
	  # Compute the Wilcoxon Test for all metrics
	  for (metric in metrics) {
  		metric_data <- wilcoxon_test(current_metrics, metric, output_data)
  		output_data <- rbind(output_data, metric_data)
	  }
	  
	  output_data$bonferroni <- p.adjust(output_data$pvalue, method = "bonferroni")
		
	  # Check statistical significance
	  output_data$significant <- ifelse(output_data$bonferroni <= 0.05, output_data$significant <- TRUE, output_data$significant <- FALSE)
	  
	  output_data$pvalue <- format.pval(pv = output_data$pvalue, 
	              
	              # digits : number of digits, but after the 0.0
	              digits = 2, 
	              
	              # eps = the threshold value above wich the 
	              # function will replace the pvalue by "<0.0xxx"
	              eps = 0.001, 
	              
	              # nsmall = how much tails 0 to keep if digits of 
	              # original value < to digits defined
	              nsmall = 3
	  )
	  
	  output_data$bonferroni <- format.pval(pv = output_data$bonferroni, 
	                                    
	                                    # digits : number of digits, but after the 0.0
	                                    digits = 2, 
	                                    
	                                    # eps = the threshold value above wich the 
	                                    # function will replace the pvalue by "<0.0xxx"
	                                    eps = 0.001, 
	                                    
	                                    # nsmall = how much tails 0 to keep if digits of 
	                                    # original value < to digits defined
	                                    nsmall = 3
	  )
	  
	  output_path <- paste0("result_", input_type)
	  output_path <- paste0(output_path, project)
	  output_path <- paste0(output_path, ".csv")


	  output_data$cliffs <- ifelse(output_data$cliff > 0, output_data$cliffs <- '+', output_data$cliffs <- '-')
	  
	  output_data$magnitude <- output_data$cliff_ctg
	  
	  output_data$cliff <- NULL
	  output_data$pvalue <- NULL
	  output_data$bonferroni <- NULL
	  output_data$cliff_ctg <- NULL
	  
	  print(paste("Project:", project))
	  print(output_data)
	  write.csv(output_data, output_path, row.names = FALSE)
	}
}
