#in the command line: Rscript script.R
setwd("./results")

system <- "ML_techniques_Implementation"

SVM <- c(0.48, 0.48, 0.64, 0.67, 0.64, 0.68, 0.62, 0.61, 0.76, 0.75, 0.76, 0.77, 0.63, 0.51, 0.8, 0.79, 0.8, 0.8, 0.68, 0.68, 0.62, 0.62, 0.62, 0.72, 0.59, 0.6, 0.68, 0.65, 0.68, 0.69, 0.4, 0.4, 0.66, 0.66, 0.66, 0.69, 0.57, 0.58, 0.68, 0.66, 0.68, 0.66, 0.55, 0.53, 0.64, 0.64, 0.66, 0.66)
DecisionTree <- c(0.77, 0.74, 0.92, 0.93, 0.92, 0.9, 0.82, 0.79, 0.96, 0.96, 0.96, 0.93, 0.83, 0.63, 0.95, 0.94, 0.95, 0.93, 0.71, 0.69, 0.92, 0.91, 0.92, 0.86, 0.72, 0.71, 0.9, 0.9, 0.9, 0.84, 0.72, 0.72, 0.91, 0.91, 0.91, 0.86, 0.73, 0.74, 0.93, 0.8, 0.93, 0.8, 0.72, 0.72, 0.91, 0.91, 0.86, 0.87)
RandomForest <- c(0.81, 0.82, 0.94, 0.94, 0.94, 0.94, 0.87, 0.82, 0.97, 0.97, 0.97, 0.96, 0.88, 0.66, 0.96, 0.96, 0.96, 0.96, 0.78, 0.79, 0.94, 0.95, 0.94, 0.93, 0.78, 0.78, 0.93, 0.93, 0.93, 0.92, 0.79, 0.79, 0.94, 0.94, 0.94, 0.93, 0.81, 0.81, 0.96, 0.81, 0.96, 0.81, 0.79, 0.79, 0.94, 0.94, 0.93, 0.93)
NaiveBayes <- c(0.36, 0.37, 0.42, 0.51, 0.42, 0.44, 0.22, 0.67, 0.56, 0.56, 0.56, 0.55, 0.29, 0.45, 0.78, 0.73, 0.78, 0.74, 0.29, 0.29, 0.67, 0.7, 0.67, 0.62, 0.26, 0.33, 0.64, 0.58, 0.64, 0.5, 0.37, 0.37, 0.59, 0.57, 0.59, 0.49, 0.3, 0.27, 0.29, 0.48, 0.29, 0.47, 0.25, 0.23, 0.71, 0.71, 0.64, 0.61)
GradientBoosting <- c(0.84, 0.83, 0.94, 0.92, 0.94, 0.93, 0.89, 0.82, 0.96, 0.97, 0.96, 0.97, 0.89, 0.67, 0.96, 0.96, 0.96, 0.96, 0.79, 0.79, 0.94, 0.94, 0.94, 0.93, 0.78, 0.78, 0.93, 0.93, 0.93, 0.91, 0.8, 0.81, 0.94, 0.94, 0.94, 0.93, 0.82, 0.82, 0.96, 0.81, 0.96, 0.81, 0.8, 0.8, 0.94, 0.94, 0.93, 0.93)
LogisticRegression <- c(0.57, 0.57, 0.69, 0.67, 0.69, 0.68, 0.63, 0.63, 0.77, 0.77, 0.77, 0.77, 0.65, 0.59, 0.82, 0.81, 0.82, 0.81, 0.65, 0.65, 0.68, 0.68, 0.68, 0.71, 0.6, 0.6, 0.72, 0.72, 0.72, 0.73, 0.56, 0.56, 0.72, 0.72, 0.72, 0.73, 0.56, 0.56, 0.72, 0.69, 0.72, 0.69, 0.58, 0.58, 0.69, 0.69, 0.7, 0.7)


sink(paste(system, "_F1_summary.txt", sep = ""))
    cat("\n\n--- --- --- SVM --- --- --- ---\n")
    summary(SVM)
    cat("\nStandard deviation: ") 
    sd(SVM) 

    cat("\n\n--- --- --- DecisionTree --- --- --- ---\n")
    summary(DecisionTree)
    cat("\nStandard deviation: ") 
    sd(DecisionTree) 

    cat("\n\n--- --- --- RandomForest --- --- --- ---\n")
    summary(RandomForest)
    cat("\nStandard deviation: ") 
    sd(RandomForest) 

    cat("\n\n--- --- --- NaiveBayes --- --- --- ---\n")
    summary(NaiveBayes)
    cat("\nStandard deviation: ") 
    sd(NaiveBayes) 

    cat("\n\n--- --- --- GradientBoosting --- --- --- ---\n")
    summary(GradientBoosting)
    cat("\nStandard deviation: ") 
    sd(GradientBoosting) 

    cat("\n\n--- --- --- LogisticRegression --- --- --- ---\n")
    summary(LogisticRegression)
    cat("\nStandard deviation: ") 
    sd(LogisticRegression) 
sink()

sink(paste(system, "_F1_friedman.txt", sep = ""))
    AR1 <- cbind(SVM, DecisionTree, RandomForest, NaiveBayes, GradientBoosting, LogisticRegression)
    require(PMCMR)
    cat("--- --- --- --- --- --- --- --- --- --- --- --- --- ---")
    friedman.test(AR1)
    #cat("--- --- --- --- --- --- --- --- --- --- --- --- --- ---")
    #posthoc.friedman.conover.test(AR1)
    cat("--- --- --- --- --- --- --- --- --- --- --- --- --- ---")
    posthoc.friedman.nemenyi.test(AR1)
    cat("--- --- --- --- --- --- --- --- --- --- --- --- --- ---")
sink()


pdf(file=paste(system, "_F1_boxplot.pdf", sep = ""))
par(cex.lab=1.0)
par(cex.axis=1.0)
#par(mgp = c(3, 2, 0)) #mgp sets position of axis label, tick labels and axis
#par(mar = c(10, 10, 10, 10) + 0.2) #margin
boxplot(SVM, DecisionTree, RandomForest, NaiveBayes, GradientBoosting, LogisticRegression, las=1, names=c("","","","","",""), ylim = c(0.2, 1))
axis(1,at=1:6, c("SVM\n", "Decision\nTree", "Random\nForest","Naive\nBayes", "Gradient\nBoosting", "Logistic\nRegression"), line=0.5, lwd=0)


sink(paste(system, "_F1_effectSize_VD-A.txt", sep = ""))
    library(effsize)
    cat("VD.A: Vargha and Delaney A measure")
    cat("\n--- --- --- treatment/control --- --- ---")
    VD.A(SVM,RandomForest)
    cat("\n--- --- --- treatment/control --- --- ---")
    VD.A(GradientBoosting,RandomForest)
    cat("\n--- --- --- treatment/control --- --- ---")
    VD.A(SVM,GradientBoosting)
sink()
