#!/bin/sh

#run all R scripts with statistic tests
FILES=./r_scripts/*
for f in $FILES
do
	echo "Processing $f"
	Rscript $f
done

#crop boxplot margins in the pdf files
FILES=./results/*.pdf
for f in $FILES
do
    echo "pdfcrop $f"
    pdfcrop --margin 1 $f $f
done
