#in the command line: Rscript script.R
setwd("./results")

system <- "GradientBoosting_Implementation"

S_all <- c(0.84, 0.89, 0.89, 0.79, 0.78, 0.8, 0.82, 0.8)
S_fs <- c(0.83, 0.82, 0.67, 0.79, 0.78, 0.81, 0.82, 0.8)
T_all <- c(0.94, 0.96, 0.96, 0.94, 0.93, 0.94, 0.96, 0.94)
T_fs <- c(0.92, 0.97, 0.96, 0.94, 0.93, 0.94, 0.81, 0.94)
ST_all <- c(0.94, 0.96, 0.96, 0.94, 0.93, 0.94, 0.96, 0.93)
ST_fs <- c(0.93, 0.97, 0.96, 0.93, 0.91, 0.93, 0.81, 0.93)


sink(paste(system, "_F1_summary.txt", sep = ""))
    cat("\n\n--- --- --- S_all --- --- --- ---\n")
    summary(S_all)
    cat("\nStandard deviation: ") 
    sd(S_all) 

    cat("\n\n--- --- --- S_fs --- --- --- ---\n")
    summary(S_fs)
    cat("\nStandard deviation: ") 
    sd(S_fs) 

    cat("\n\n--- --- --- T_all --- --- --- ---\n")
    summary(T_all)
    cat("\nStandard deviation: ") 
    sd(T_all) 

    cat("\n\n--- --- --- T_fs --- --- --- ---\n")
    summary(T_fs)
    cat("\nStandard deviation: ") 
    sd(T_fs) 

    cat("\n\n--- --- --- ST_all --- --- --- ---\n")
    summary(ST_all)
    cat("\nStandard deviation: ") 
    sd(ST_all) 

    cat("\n\n--- --- --- ST_fs --- --- --- ---\n")
    summary(ST_fs)
    cat("\nStandard deviation: ") 
    sd(ST_fs) 
sink()

sink(paste(system, "_F1_friedman.txt", sep = ""))
    AR1 <- cbind(S_all, S_fs, T_all, T_fs, ST_all, ST_fs)
    require(PMCMR)
    cat("--- --- --- --- --- --- --- --- --- --- --- --- --- ---")
    friedman.test(AR1)
    #cat("--- --- --- --- --- --- --- --- --- --- --- --- --- ---")
    #posthoc.friedman.conover.test(AR1)
    cat("--- --- --- --- --- --- --- --- --- --- --- --- --- ---")
    posthoc.friedman.nemenyi.test(AR1)
    cat("--- --- --- --- --- --- --- --- --- --- --- --- --- ---")
sink()


pdf(file=paste(system, "_F1_boxplot.pdf", sep = ""))
par(cex.lab=1.8)
par(cex.axis=1.8)
#par(mgp = c(3, 2, 0)) #mgp sets position of axis label, tick labels and axis
#par(mar = c(10, 10, 10, 10) + 0.2) #margin
boxplot(S_all, S_fs, T_all, T_fs, ST_all, ST_fs, las=1, names=c("","","","","",""), ylim = c(0.65, 1))
axis(1,at=1:6, c("S\nall", "S\nfs", "T\nall","T\nfs", "ST\nall", "ST\nfs"), line=2, lwd=0)


sink(paste(system, "_F1_effectSize_VD-A.txt", sep = ""))
    library(effsize)
    cat("VD.A: Vargha and Delaney A measure")
    cat("\n--- --- --- treatment/control --- --- ---")
    VD.A(S_all,T_all)
    cat("\n--- --- --- treatment/control --- --- ---")
    VD.A(ST_all,T_all)
    cat("\n--- --- --- treatment/control --- --- ---")
    VD.A(S_all,ST_all)
sink()
